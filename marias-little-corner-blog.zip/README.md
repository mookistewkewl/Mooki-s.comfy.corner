# Maria's Little Corner ✨

A personal blog made with plain HTML and CSS.

## Put it on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish it.

To add photos later, upload the image files to the repository and edit the photo boxes in `index.html`.
